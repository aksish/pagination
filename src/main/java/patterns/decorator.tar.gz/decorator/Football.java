package patterns.decorator;

/**
 * Created by Aashis Khanal on 8/18/15.
 */
public class Football implements Game {
    public void play() {
        System.out.println("New Football game");
    }
}
