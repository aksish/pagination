package patterns.decorator;

/**
 * Created by Aashis Khanal on 8/18/15.
 */
public interface Game {
    public void play();
}
